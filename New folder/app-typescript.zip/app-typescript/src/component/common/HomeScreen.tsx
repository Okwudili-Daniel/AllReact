import React from 'react'
import Hero from './Hero'

const HomeScreen = () => {
  return (
    <div>
      <Hero/>
    </div>
  )
}

export default HomeScreen
