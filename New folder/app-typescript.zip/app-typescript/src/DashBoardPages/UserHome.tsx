import React from 'react'
import styled from 'styled-components';

const UserHome = () => {
  return (
    <div>
      <Container>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias illum quisquam quod repellendus laudantium suscipit, quidem soluta consequatur repudiandae animi perferendis. Eos dolore unde architecto illo fugit deserunt aperiam exercitationem ab sint suscipit beatae, inventore labore velit assumenda ut accusamus totam cupiditate quas, excepturi obcaecati enim? Unde debitis eligendi dolorum.
      </Container>
    </div>
  )
}

export default UserHome;
const Container = styled.div`
    margin-top: 20px;
`
